package com.mycloudindo.simtofly

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
